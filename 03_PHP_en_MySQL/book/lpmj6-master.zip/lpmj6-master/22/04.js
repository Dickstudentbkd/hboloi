// The smallest jQuery 'ready' code encapsulation function
// -- Make sure jQuery is loaded first

$(function()
{
  // Your code goes here
})
