<?php
  $query  = "SELECT * FROM classics";
  $result = $pdo->query($query);
?>
