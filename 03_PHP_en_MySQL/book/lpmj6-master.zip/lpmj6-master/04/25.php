<?php
  switch ($page):
  	case "Home":
  		echo "You selected Home";
  		break;
  
  	// etc...
  
  	case "Links":
  		echo "You selected Links";
  		break;
  endswitch;
?>
